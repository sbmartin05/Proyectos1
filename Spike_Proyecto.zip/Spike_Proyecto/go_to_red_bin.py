from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Stop

motor = Motor(Port.E)
motor.run_target(100, 90, then=Stop.HOLD, wait=True)
