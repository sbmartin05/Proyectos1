import tkinter as tk
import asyncio
import threading
from conector_spike import spike

# Ejecutar una corrutina sin bloquear la GUI
def run_async(coro):
    threading.Thread(target=lambda: asyncio.run(coro)).start()

# Ejecutar un script en el Spike
def ejecutar(script):
    output.insert(tk.END, f"Ejecutando {script}...\n")
    output.see(tk.END)
    run_async(spike.run_file(script))

# Conectar automáticamente al iniciar
def conectar_spike():
    output.insert(tk.END, "Conectando al Spike SP-7...\n")
    output.see(tk.END)
    run_async(spike.connect())

# Desconectar automáticamente al cerrar GUI
def cerrar():
    output.insert(tk.END, "Cerrando conexión...\n")
    output.see(tk.END)
    asyncio.run(spike.disconnect())
    root.destroy()

# GUI
root = tk.Tk()
root.title("Control Spike SP-7")

# Botones
frame = tk.Frame(root)
frame.pack(pady=10)

tk.Button(frame, text="Posición de lectura (0°)", width=30,
          command=lambda: ejecutar("go_to_read_position.py")).grid(row=0, column=0)

tk.Button(frame, text="Bandeja Roja (90°)", width=30,
          command=lambda: ejecutar("go_to_red_bin.py")).grid(row=1, column=0)

tk.Button(frame, text="Bandeja Verde (-45°)", width=30,
          command=lambda: ejecutar("go_to_green_bin.py")).grid(row=2, column=0)

tk.Button(frame, text="Bandeja Azul (-70°)", width=30,
          command=lambda: ejecutar("go_to_blue_bin.py")).grid(row=3, column=0)

tk.Button(frame, text="Bandeja Amarilla (125°)", width=30,
          command=lambda: ejecutar("go_to_yellow_bin.py")).grid(row=4, column=0)

tk.Button(frame, text="Abrir compuerta", width=30,
          command=lambda: ejecutar("open_gate.py")).grid(row=5, column=0)

tk.Button(frame, text="Cerrar compuerta", width=30,
          command=lambda: ejecutar("close_gate.py")).grid(row=6, column=0)

tk.Button(frame, text="Ejecutar test2.py completo", width=30,
          command=lambda: ejecutar("test2.py")).grid(row=7, column=0)

# Área de salida
output = tk.Text(root, height=20, width=80)
output.pack(pady=10)

# Conectar al iniciar
conectar_spike()

# Cerrar correctamente
root.protocol("WM_DELETE_WINDOW", cerrar)

root.mainloop()
