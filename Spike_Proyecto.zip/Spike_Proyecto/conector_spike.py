import tkinter as tk
import subprocess
import threading
import os

SPIKE_NAME = "SP-7"

# Función para ejecutar archivos .py en el Spike por Bluetooth
def run_on_spike(script_file):
    def task():
        try:
            output_text.insert(tk.END, f"Ejecutando {script_file} en {SPIKE_NAME}...\n")
            output_text.see(tk.END)

            result = subprocess.run(
                ["python", "-m", "pybricksdev", "run", "--name", SPIKE_NAME, "ble", script_file],
                capture_output=True,
                text=True
            )

            if result.stdout:
                output_text.insert(tk.END, result.stdout + "\n")
            if result.stderr:
                output_text.insert(tk.END, "ERROR:\n" + result.stderr + "\n")

            output_text.see(tk.END)

        except Exception as e:
            output_text.insert(tk.END, f"Error ejecutando {script_file}: {e}\n")
            output_text.see(tk.END)

    threading.Thread(target=task).start()


# Crear ventana
root = tk.Tk()
root.title("Control Spike SP-7")

# Botones de movimiento
frame = tk.Frame(root)
frame.pack(pady=10)

tk.Button(frame, text="Ir a posición de lectura (0°)", width=30,
          command=lambda: run_on_spike("go_to_read_position.py")).grid(row=0, column=0)

tk.Button(frame, text="Bandeja Roja (90°)", width=30,
          command=lambda: run_on_spike("go_to_red_bin.py")).grid(row=1, column=0)

tk.Button(frame, text="Bandeja Verde (-45°)", width=30,
          command=lambda: run_on_spike("go_to_green_bin.py")).grid(row=2, column=0)

tk.Button(frame, text="Bandeja Azul (-70°)", width=30,
          command=lambda: run_on_spike("go_to_blue_bin.py")).grid(row=3, column=0)

tk.Button(frame, text="Bandeja Amarilla (125°)", width=30,
          command=lambda: run_on_spike("go_to_yellow_bin.py")).grid(row=4, column=0)

tk.Button(frame, text="Abrir compuerta", width=30,
          command=lambda: run_on_spike("open_gate.py")).grid(row=5, column=0)

tk.Button(frame, text="Cerrar compuerta", width=30,
          command=lambda: run_on_spike("close_gate.py")).grid(row=6, column=0)

tk.Button(frame, text="Ejecutar test2.py completo", width=30,
          command=lambda: run_on_spike("test2.py")).grid(row=7, column=0)

# Área de salida
output_text = tk.Text(root, height=20, width=80)
output_text.pack(pady=10)

root.mainloop()