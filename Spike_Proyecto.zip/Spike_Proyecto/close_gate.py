from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Stop

gate = Motor(Port.F)
gate.run_target(100, 15, then=Stop.HOLD, wait=True)
