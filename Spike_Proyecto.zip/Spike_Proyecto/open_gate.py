from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Stop

gate = Motor(Port.F)
gate.run_target(100, -40, then=Stop.HOLD, wait=True)
