from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port, Stop
from pybricks.tools import wait

motor = Motor(Port.E)
gate = Motor(Port.F)
sensor = ColorSensor(Port.C)

pos_read = 0
pos_red = 90
pos_green = -45
pos_blue = -70
pos_yellow = 125

gate_open = -40
gate_close = 15

def go_and_drop(position):
    motor.run_target(100, position, then=Stop.HOLD, wait=True)
    gate.run_target(100, gate_open, then=Stop.HOLD, wait=True)
    wait(300)
    gate.run_target(100, gate_close, then=Stop.HOLD, wait=True)
    motor.run_target(100, pos_read, then=Stop.HOLD, wait=True)

while True:
    detected = sensor.color()
    print("Color detectado:", detected)

    if detected == "red":
        go_and_drop(pos_red)
    elif detected == "green":
        go_and_drop(pos_green)
    elif detected == "blue":
        go_and_drop(pos_blue)
    elif detected == "yellow":
        go_and_drop(pos_yellow)

    wait(500)
